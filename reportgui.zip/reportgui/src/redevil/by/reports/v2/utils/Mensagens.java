package redevil.by.reports.v2.utils;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.ConsoleCommandSender;

import redevil.by.reports.v2.FilesUtils;

public class Mensagens {

	private static String getNome = FilesUtils.getFile().getName().toString();
	private static ConsoleCommandSender cc = Bukkit.getConsoleSender();
	
	public static void arquivoNaoExiste() {
		Bukkit.getOnlinePlayers().stream().filter(a -> a.isOp() || a.isOnline()).forEach(b -> {
			b.sendMessage("");
			b.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b&l[Aviso] &cO arquivo " + getNome.toUpperCase() + " n�o existe. Um novo foi gerado."));
			b.sendMessage("");
			Utils.sendSom(b, Sound.CLICK);
			
		});
	}
	
	public static void arquivoNaoExisteConsole() {
		cc.sendMessage("");
		cc.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b&l[Aviso] &cO arquivo " + getNome.toUpperCase() + " n�o existe. Um novo foi gerado."));
		cc.sendMessage("");
		
	}
}
