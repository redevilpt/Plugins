package redevil.by.reports.v2.utils;

import java.util.HashMap;

import org.bukkit.entity.Player;

public class Armazenamento {

	public static HashMap<String, String> jogadorReportado = new HashMap<String, String>();
	public static HashMap<Player, Long> delay = new HashMap<Player, Long>();
	
}
