package redevil.by.reports.v2.utils;

import java.util.Random;

import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

import net.minecraft.server.v1_8_R3.IChatBaseComponent;
import net.minecraft.server.v1_8_R3.Packet;
import net.minecraft.server.v1_8_R3.PacketPlayOutChat;
import net.minecraft.server.v1_8_R3.PacketPlayOutTitle;
import net.minecraft.server.v1_8_R3.PacketPlayOutTitle.EnumTitleAction;

public class Utils {

	public static String gerarCodigo(int tamanho) {
		StringBuilder sb = new StringBuilder();
		String codigo = "1234567890";
		int i = 0;
		for (int t = 0; t < tamanho; t++) {
			i = new Random().nextInt(codigo.length());
			sb.append(codigo.subSequence(i, i + 1));

		}
		return sb.toString();

	}

	public static void sendTitle(Player p, String titulo, String subtitulo) {
		Packet<?> t1 = new PacketPlayOutTitle(EnumTitleAction.TITLE,
				IChatBaseComponent.ChatSerializer.a("{\"text\":\"" + titulo + "\"}"));
		((CraftPlayer) p).getHandle().playerConnection.sendPacket(t1);
		Packet<?> t2 = new PacketPlayOutTitle(EnumTitleAction.SUBTITLE,
				IChatBaseComponent.ChatSerializer.a("{\"text\":\"" + subtitulo + "\"}"));
		((CraftPlayer) p).getHandle().playerConnection.sendPacket(t2);

	}

	public static void sendActionbar(Player p, String mensagem) {
		IChatBaseComponent chat = IChatBaseComponent.ChatSerializer.a("{\"text\":\"" + mensagem + "\"}");
		Packet<?> packet = new PacketPlayOutChat(chat, (byte) 2);
		((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);

	}

	public static void sendSom(Player p, Sound som) {
		p.playSound(p.getLocation(), som, 1F, 1F);

	}

}
