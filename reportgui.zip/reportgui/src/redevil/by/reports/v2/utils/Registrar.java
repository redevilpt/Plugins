package redevil.by.reports.v2.utils;

import org.bukkit.command.CommandExecutor;
import org.bukkit.plugin.java.JavaPlugin;

import redevil.by.reports.v2.Comando;
import redevil.by.reports.v2.Main;

public class Registrar {

	private static JavaPlugin m = Main.getPlugin(Main.class);
	
	public static void setComando(String comando, CommandExecutor classe) {
		m.getCommand(comando).setExecutor(classe);
		
	}
	
	public static void registrarComando() {
		setComando("denunciar", new Comando());
		
	}
}
