package redevil.by.reports.v2;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import redevil.by.reports.v2.utils.Armazenamento;

public class Inventario {

	public static FileConfiguration getConfigFile = FilesUtils.getFile();
	private static JavaPlugin m = Main.getPlugin(Main.class);

	public static void openInventario(Player p) {
		
		Inventory inv = Bukkit.createInventory(null, m.getConfig().getInt("inventarioTamanho") * 9,
				ChatColor.translateAlternateColorCodes('&', "&8Den�ncias"));
		p.openInventory(inv);
		
		for (String key : FilesUtils.getFile().getConfigurationSection("motivos").getKeys(false)) {

			Player target = Bukkit.getPlayerExact(Armazenamento.jogadorReportado.get(p.getName()));


			ItemStack item = new ItemStack(
					Material.getMaterial(getConfigFile.getString("motivos." + key + ".nomeItem")), 1,
					(short) getConfigFile.getInt("motivos." + key + ".data"));
			ItemMeta itemMeta = item.getItemMeta();
			itemMeta.setDisplayName(getConfigFile.getString("motivos." + key + ".nomeDisplay").replace("&", "�"));

			ArrayList<String> lore = new ArrayList<String>();
			for (String str : getConfigFile.getStringList("motivos." + key + ".lore")) {
				lore.add(str.replace('&', '�').replace("{suspeito}", target.getName().toString()).replace("{motivo}",
						itemMeta.getDisplayName()));

			}

			itemMeta.setLore(lore);
			item.setItemMeta(itemMeta);

			inv.setItem(getConfigFile.getInt("motivos." + key + ".slot"), item);

		}
	}
}
