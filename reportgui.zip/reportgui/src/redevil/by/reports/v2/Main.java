package redevil.by.reports.v2;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import redevil.by.reports.v2.utils.Registrar;

public class Main extends JavaPlugin {
	
	@Override
	public void onEnable() {
		
		Bukkit.getPluginManager().registerEvents(new Eventos(), this);
		Registrar.registrarComando();
		FilesUtils.setupFiles();
		saveDefaultConfig();
		
	}

}
