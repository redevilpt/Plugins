package redevil.by.reports.v2;

import java.io.File;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import redevil.by.reports.v2.utils.Mensagens;

public class FilesUtils {

	private static File f;
	private static FileConfiguration cfile;
	private static JavaPlugin m = Main.getPlugin(Main.class);

	public static void setupFiles() {
		f = new File(m.getDataFolder(), "motivos.yml");
		if (!f.exists()) {
			m.saveResource("motivos.yml", false);
			Mensagens.arquivoNaoExiste();
			Mensagens.arquivoNaoExisteConsole();

		}
	}

	public static FileConfiguration getFile() {
		if (cfile == null) {
			f = new File(m.getDataFolder(), "motivos.yml");
			cfile = YamlConfiguration.loadConfiguration(f);

		}

		return cfile;

	}

	public static void saveFile() {
		try {
			getFile().save(f);
		} catch (Exception e) {
		}
	}

	public static void reloadFile() {
		if (f == null) {
			f = new File(m.getDataFolder(), "motivos.yml");

		}

		YamlConfiguration cfile = YamlConfiguration.loadConfiguration(f);

		if (cfile != null) {
			YamlConfiguration defaults = YamlConfiguration.loadConfiguration(f);
			getFile().setDefaults(defaults);
		}
	}
}
