package redevil.by.reports.v2;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import redevil.by.reports.v2.utils.Armazenamento;
import redevil.by.reports.v2.utils.Utils;

public class Comando implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String lb, String[] args) {
		if (!(sender instanceof Player)) {
			sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&cApenas para jogadores in-game."));
			return true;

		}

		Player p = (Player) sender;
		if (cmd.getName().equalsIgnoreCase("denunciar")) {
			if (args.length == 0) {
				Utils.sendActionbar(p, ChatColor.translateAlternateColorCodes('&',
						"&c[&4&l!&c] &nUtilize: /denunciar <jogador>&c [&4&l!&c]"));
				Utils.sendSom(p, Sound.NOTE_PLING);
				return true;

			}

			Player target = Bukkit.getPlayer(args[0]);
			if (target == null) {
				Utils.sendTitle(p, ChatColor.translateAlternateColorCodes('&', ""),
						ChatColor.translateAlternateColorCodes('&', "&cEste jogador n�o existe."));
				return true;

			}
			
			Armazenamento.jogadorReportado.put(p.getName(), target.getName());
			Inventario.openInventario(p);

		}
		return false;

	}

}
