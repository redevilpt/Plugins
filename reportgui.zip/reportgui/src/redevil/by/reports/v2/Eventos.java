package redevil.by.reports.v2;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.plugin.java.JavaPlugin;

import redevil.by.reports.v2.utils.Armazenamento;
import redevil.by.reports.v2.utils.Utils;

public class Eventos implements Listener {

	private static JavaPlugin m = Main.getPlugin(Main.class);
	private static FileConfiguration getFileConfig = FilesUtils.getFile();

	@EventHandler
	public void aoClicar(InventoryClickEvent e) {
		long agora = System.currentTimeMillis();
		if (e.getWhoClicked() instanceof Player) {

			Player p = (Player) e.getWhoClicked();
			Player target = Bukkit.getPlayerExact(Armazenamento.jogadorReportado.get(p.getName()));

			if (e.getInventory().getTitle().equals(ChatColor.translateAlternateColorCodes('&', "&8Den�ncias"))) {
				e.setCancelled(true);

				if (e.getCurrentItem().getType().equals(Material.AIR)) return;

				for (String key : getFileConfig.getConfigurationSection("motivos").getKeys(false)) {
					if (e.getCurrentItem().getType()
							.equals(Material.getMaterial(getFileConfig.getString("motivos." + key + ".nomeItem")))) {

						if (Armazenamento.delay.containsKey(p) && Armazenamento.delay.get(p) >= agora) {
							long restante = TimeUnit.MILLISECONDS.toSeconds(Armazenamento.delay.get(p) - agora);
							p.sendMessage(ChatColor.translateAlternateColorCodes('&',
									"&cAguarde para mandar outra den�ncia! A sua den�ncia foi cancelada. Aguarde &f" + restante
											+ "&c para enviar uma nova den�ncia."));
							p.closeInventory();
							return;

						}

						SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy - hh:mm:ss");

						Utils.sendTitle(p, "",
								ChatColor.translateAlternateColorCodes('&', "&aDen�ncia enviada com sucesso."));

						p.sendMessage("");
						p.sendMessage(ChatColor.translateAlternateColorCodes('&', " &b[!] Den�ncia enviada [!]"));
						p.sendMessage(ChatColor.translateAlternateColorCodes('&', ""));
						p.sendMessage(ChatColor.translateAlternateColorCodes('&',
								"  &aAssim que poss�vel um STAFF ir� ver a sua den�ncia e aplicar o banimento correto a este jogador (se necess�rio)"));
						p.sendMessage(ChatColor.translateAlternateColorCodes('&', ""));
						p.sendMessage(ChatColor.translateAlternateColorCodes('&', " &b[!] Den�ncia enviada [!]"));
						p.sendMessage("");

						p.closeInventory();

						Armazenamento.delay.put(p, System.currentTimeMillis() + m.getConfig().getInt("delay") * 1000);
						for (Player staff : Bukkit.getOnlinePlayers()) {
							if (staff.isOp() || staff.hasPermission(m.getConfig().getString("permissaoStaff"))) {

								Utils.sendTitle(staff,
										ChatColor.translateAlternateColorCodes('&', "&e&l-x- &aDen�ncias&e&l -x-"),
										ChatColor.translateAlternateColorCodes('&', "&a&lNova den�ncia."));

								staff.sendMessage("");
								staff.sendMessage(
										ChatColor.translateAlternateColorCodes('&', "  (((&c&lNOVA DEN�NCIA&7)))"));
								staff.sendMessage("");
								staff.sendMessage(
										ChatColor.translateAlternateColorCodes('&', "  &aJogador: &b" + p.getName()));
								staff.sendMessage(ChatColor.translateAlternateColorCodes('&',
										"  &aSuspeito: &b" + target.getName()));
								staff.sendMessage(ChatColor.translateAlternateColorCodes('&',
										"  &aHora da Den�ncia: &b" + dateFormat.format(new Date())));
								staff.sendMessage(ChatColor.translateAlternateColorCodes('&',
										"  &aMotivo: &b" + getFileConfig.getString("motivos." + key + ".motivo")));
								staff.sendMessage("");
								staff.sendMessage(
										ChatColor.translateAlternateColorCodes('&', "  (((&c&lNOVA DEN�NCIA&7)))"));
								staff.sendMessage("");

							} else {

								return;

							}
						}
					}
				}
			}
		}
	}

}
